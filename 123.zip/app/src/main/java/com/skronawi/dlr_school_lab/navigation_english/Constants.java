package com.skronawi.dlr_school_lab.navigation_english;

public class Constants {

    public static final String PREFS_PREFIX = "com.skronawi.dlr_school_lab.nav";
    public static final String PREF_NAME = PREFS_PREFIX + ".prefs_name";
}
