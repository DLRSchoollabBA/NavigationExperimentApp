package com.skronawi.dlr_school_lab.navigation_english.tasks;

public interface TrilaterationCoordReceiver {
    void setLatLon(float lat, float lon);
}
